package com.oakland.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oakland.model.Employee;
import com.oakland.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showRegistrationForm(Model model) {
		model.addAttribute("employee", new Employee());
		return "registration_form";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerEmployee(@Validated @ModelAttribute("employee") Employee employee,
			BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			return "registration_form";
		}

		// Perform validation or additional processing as needed
		// ...

		// Store the employee data using the employeeService
		registrationService.registerEmployee(employee);

		model.addAttribute("message", "Registration successful");
		return "registration_success";
	}
}