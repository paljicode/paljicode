package com.oakland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oakland.dao.RegistrationDao;
import com.oakland.model.Employee;

@Service
public class RegistrationService {

    @Autowired
    private RegistrationDao registrationDao;

    public void registerEmployee(Employee employee) {
        // Performing validation
        if (isEmployeeIdAlreadyExists(employee.getId())) {
            throw new IllegalArgumentException("Employee ID already exists");
        }

        // Perform any additional processing or validation before saving the employee
        // ...

        registrationDao.save(employee);
    }

    private boolean isEmployeeIdAlreadyExists(String id) {
        // Checking if the employee ID already exists in the database
        Employee existingEmployee = registrationDao.findEmployeeById(id);
        return existingEmployee != null;
    }
}