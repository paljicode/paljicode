package com.oakland.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oakland.model.Employee;
import com.oakland.service.LoginService;

@Controller
public class LoginController {

    @Autowired
    private LoginService loginService;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String showLoginForm() {
        return "login_form";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(String id, String password, Model model) {
        boolean loginSuccessful = loginService.authenticateEmployee(id, password);
        if (loginSuccessful) {
            // Successful login
            Employee employee = loginService.getEmployeeById(id);
            model.addAttribute("employee", employee);
            return "dashboard";
        } else {
            // Invalid login
            model.addAttribute("error", "Invalid ID or password");
            return "login_form";
        }
    }
}



