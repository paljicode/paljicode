package com.oakland.model;

public enum Gender {
	MALE, FEMALE

}
