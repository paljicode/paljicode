package com.oakland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oakland.dao.LoginDao;
import com.oakland.model.Employee;

@Service
public class LoginService {

    @Autowired
    private LoginDao loginDao;

    public boolean authenticateEmployee(String id, String password) {
        Employee employee = loginDao.findById(id);
        return employee != null && employee.getPassword().equals(password);
    }

    public Employee getEmployeeById(String id) {
        return loginDao.findById(id);
    }
}
