package com.oakland.dao;

import com.oakland.model.Employee;

public interface RegistrationDao {
 
public void save(Employee employee);	
	
public Employee findEmployeeById(String id);

public boolean isEmployeeIdAlreadyExists(String id);

}
