package com.oakland.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oakland.model.Employee;

@Repository
public class LoginDaoImpl implements LoginDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Employee findById(String id) {
		 Session session = sessionFactory.getCurrentSession();
	        return (Employee) session.get(Employee.class, id);
		
	}
     

}
	 

