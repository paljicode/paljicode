package com.oakland.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.oakland.model.Employee;

public class RegistrationDaoImpl implements RegistrationDao {

	private SessionFactory sessionFactory;

	@Override
	public void save(Employee employee) {
		getCurrentSession().save(employee);

	}

	@Override
	public Employee findEmployeeById(String id) {
		Session session = getCurrentSession();
		return (Employee) session.get(Employee.class, id);
	}

	@Override
	public boolean isEmployeeIdAlreadyExists(String id) {
		Employee existingEmployee = findEmployeeById(id);
		return existingEmployee != null;
	}

    private Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }
}
