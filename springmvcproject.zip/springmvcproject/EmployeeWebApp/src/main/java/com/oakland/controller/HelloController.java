package com.oakland.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

public class HelloController {

	@GetMapping("reqParam") //mapping the request query string parameters to Spring Controller method arguments
	public ModelAndView reqParameters(@RequestParam(required = false, name = "userName") String name) {

		ModelAndView modelAndView = new ModelAndView();

		// setting model data
		modelAndView.addObject("welMsg", "Welcome to Spring MVC user " + name); // request.setAttribute();//adding attribute to model.

		// setting view English name
		modelAndView.setViewName("welcome");

		return modelAndView;

	}

}
